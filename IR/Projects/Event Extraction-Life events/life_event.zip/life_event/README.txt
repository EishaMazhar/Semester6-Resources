Author: Jiwei Li

This dataset contains positive and negative tweets used in end-to-end evaluation in the paper ``Major Life Event Extraction from Twitter based on Congratulations/Condolences Speech Acts".

pos.txt file is comprised of 772 manually labeled tweets talking about major life events, which is a bit small than as mentioned in original paper (900) because of privacy issues.
